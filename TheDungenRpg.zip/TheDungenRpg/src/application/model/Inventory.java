package application.model;

public class Inventory {

}
